import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load the dataset
data = pd.read_csv('imdb_processed.csv')

# Encode genre into dummy variables
genre_dummies = pd.get_dummies(data['genre'], prefix='genre', drop_first=True)
data = pd.concat([data, genre_dummies], axis=1)
data.drop(columns=['genre'], inplace=True)

# Define features and target
X = data.drop(columns=['rating'])
y = data['rating']

# Convert features to numeric and drop rows with invalid data
X = X.apply(pd.to_numeric, errors='coerce')
valid_indices = X.dropna().index
X = X.loc[valid_indices]
y = y.loc[valid_indices]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build and train the regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("R2 Score:", r2)

# Display coefficients for each feature
coefficients = pd.DataFrame({'Feature': X.columns, 'Coefficient': model.coef_})
print(coefficients)
