import pandas as pd

# Load the dataset
data = pd.read_csv('imdb_processed.csv')

# Select relevant columns
data = data[['runtime', 'year', 'vote', 'rating']]  # Adjust column names as needed
data.dropna(inplace=True)  # Remove rows with missing values
