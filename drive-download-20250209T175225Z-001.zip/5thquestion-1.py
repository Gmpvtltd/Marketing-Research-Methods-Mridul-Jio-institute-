import pandas as pd

# Load your dataset (replace 'your_dataset.csv' with the actual dataset file name)
data = pd.read_csv('imdb_processed.csv')

# Clean and preprocess the data
data['director'] = data['director'].str.strip("[]").str.replace("'", "").str.split(", ")

# Explode the list into individual rows
data = data.explode('director')

# Count the occurrences of each director
director_counts = data['director'].value_counts()

# Filter directors with more than one entry
significant_directors = director_counts[director_counts > 1].index
