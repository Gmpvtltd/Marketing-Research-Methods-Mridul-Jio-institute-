from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
import pandas as pd
data = pd.read_csv('imdb_processed.csv')
# Clean and preprocess the data
data['director'] = data['director'].str.strip("[]").str.replace("'", "").str.split(", ")
data = data.explode('director')  # Handle multiple directors in a single entry

# Count the occurrences of each director
director_counts = data['director'].value_counts()

# Filter directors with more than one entry
significant_directors = director_counts[director_counts > 1].index

# Create a categorical variable for these directors
data['is_significant_director'] = data['director'].apply(
    lambda x: 1 if x in significant_directors else 0
)

# Prepare the dataset for regression analysis
regression_data = data[['rating', 'is_significant_director']].dropna()

# Regression analysis
X = sm.add_constant(regression_data['is_significant_director'])
y = regression_data['rating']
model = sm.OLS(y, X).fit()

# Summary of the regression model
model_summary = model.summary()
model_summary
