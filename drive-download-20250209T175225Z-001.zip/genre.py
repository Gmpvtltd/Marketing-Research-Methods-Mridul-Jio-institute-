import pandas as pd

# Load the dataset
data = pd.read_csv('imdb_processed.csv')

# Encode genre as dummy variables
genre_dummies = pd.get_dummies(data['genre'], prefix='genre', drop_first=True)

# Merge dummy variables with the dataset
data = pd.concat([data, genre_dummies], axis=1)

# Drop the original genre column
data.drop(columns=['genre'], inplace=True)

# Optional: Save the updated dataset to a new file
data.to_csv('imdb_processed_with_genres.csv', index=False)
