import praw
from textblob import TextBlob
import pandas as pd
import os

# Step 1: Authenticate with Reddit API
reddit = praw.Reddit(
    client_id='YOUR_CLIENT_ID',
    client_secret='YOUR_CLIENT_SECRET',
    user_agent='YOUR_USER_AGENT'
)

# Step 2: Define the subreddit and extract posts
subreddit_name = 'YourFavoriteSubreddit'  # Replace with your chosen subreddit
subreddit = reddit.subreddit(subreddit_name)

# Extract top 10 hot posts
posts_data = []
for post in subreddit.hot(limit=10):
    posts_data.append({
        'title': post.title,
        'selftext': post.selftext,
        'score': post.score,
        'num_comments': post.num_comments
    })

# Step 3: Extract comments for each post
comments_data = []
for post in subreddit.hot(limit=10):
    post.comments.replace_more(limit=0)  # Fetch all comments without "More Comments" placeholders
    for comment in post.comments.list():
        comments_data.append({
            'comment': comment.body,
            'score': comment.score
        })

# Step 4: Perform Sentiment Analysis
def analyze_sentiment(text):
    analysis = TextBlob(text)
    return analysis.sentiment.polarity  # Polarity: -1 (negative) to +1 (positive)

# Add sentiment scores for posts
for post in posts_data:
    post['title_sentiment'] = analyze_sentiment(post['title'])
    post['selftext_sentiment'] = analyze_sentiment(post['selftext'])

# Add sentiment scores for comments
for comment in comments_data:
    comment['sentiment'] = analyze_sentiment(comment['comment'])

# Step 5: Save results to a CSV file
output_dir = './reddit_analysis'
os.makedirs(output_dir, exist_ok=True)

# Save posts
posts_df = pd.DataFrame(posts_data)
posts_df.to_csv(os.path.join(output_dir, 'posts_analysis.csv'), index=False)

# Save comments
comments_df = pd.DataFrame(comments_data)
comments_df.to_csv(os.path.join(output_dir, 'comments_analysis.csv'), index=False)

print(f"Analysis saved to {output_dir}")
