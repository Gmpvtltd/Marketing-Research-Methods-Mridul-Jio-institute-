import pandas as pd
from statsmodels.api import OLS, add_constant
import os

# Step 1: Load the dataset
file_path = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping/imdb_processed.csv'
data = pd.read_csv(file_path)

# Step 2: Preprocess the "language" column to count the number of languages
data['language'] = data['language'].fillna('[]')  # Replace NaN with empty list-like string
data['language_count'] = data['language'].str.strip("[]").str.replace("'", "").str.split(", ").apply(len)

# Step 3: Prepare data for regression
# Keep only relevant columns and drop rows with missing values
data = data.dropna(subset=['rating', 'runtime', 'vote'])

# Define independent variables (include language_count, runtime, and vote)
X = data[['language_count', 'runtime', 'vote']]
y = data['rating']

# Add a constant for the regression model
X = add_constant(X)

# Step 4: Fit the regression model
model_language = OLS(y, X).fit()

# Step 5: Save the regression results to a text file
output_dir = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping'
output_file_language = os.path.join(output_dir, 'language_analysis.txt')

# Ensure the directory exists
os.makedirs(output_dir, exist_ok=True)

# Save the regression summary to a text file
with open(output_file_language, 'w') as f:
    f.write("Regression Analysis: Effect of Language Count on Rating\n")
    f.write(str(model_language.summary()))

print(f"Analysis saved to {output_file_language}")
