from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(drop='first', sparse_output=False)
encoded_countries = encoder.fit_transform(data[['country']])
import statsmodels.api as sm
import numpy as np
import pandas as pd

# Load your dataset (update the path to your CSV file)
data = pd.read_csv('imdb_processed.csv')

# Check the dataset structure
print(data.head())
from sklearn.preprocessing import OneHotEncoder

# Preprocess the 'country' column
data['country'] = data['country'].astype(str).str.strip("[]").str.replace("'", "").str.split(", ")
data = data.explode('country')

# Check the processed data
print(data['country'].head())

# Encode the 'country' column
encoder = OneHotEncoder(drop='first', sparse_output=False)  # Use sparse=False for older versions
encoded_countries = encoder.fit_transform(data[['country']])

# Convert the encoded data to a DataFrame
encoded_country_df = pd.DataFrame(encoded_countries, columns=encoder.get_feature_names_out(['country']))
from sklearn.preprocessing import OneHotEncoder

# Preprocess the 'country' column
data['country'] = data['country'].astype(str).str.strip("[]").str.replace("'", "").str.split(", ")
data = data.explode('country')

# Check the processed data
print(data['country'].head())

# Encode the 'country' column
encoder = OneHotEncoder(drop='first', sparse_output=False)  # Use sparse=False for older versions
encoded_countries = encoder.fit_transform(data[['country']])

# Convert the encoded data to a DataFrame
encoded_country_df = pd.DataFrame(encoded_countries, columns=encoder.get_feature_names_out(['country']))
# Combine the encoded data with the target variable
X = encoded_country_df
y = data['rating']

# Check the shapes of X and y
print(f"Features shape: {X.shape}, Target shape: {y.shape}")

# Preprocessing the data
# Expand the country column into a usable format (removing brackets and splitting if necessary)
data['country'] = data['country'].str.strip("[]").str.replace("'", "").str.split(", ")
data = data.explode('country')

# Remove rows with missing country or rating
filtered_data = data.dropna(subset=['country', 'rating'])

# One-hot encode the country column
encoder = OneHotEncoder(drop='first', sparse=False)
encoded_countries = encoder.fit_transform(filtered_data[['country']])

# Create a DataFrame for encoded country columns
encoded_country_df = pd.DataFrame(encoded_countries, columns=encoder.get_feature_names_out(['country']))

# Combine with the original data
X = pd.concat([encoded_country_df], axis=1)
y = filtered_data['rating']

# Add a constant for statsmodels regression
X = sm.add_constant(X)

# Train regression model
model = sm.OLS(y, X).fit()

# Summarize the regression results
regression_summary = model.summary()
regression_summary
