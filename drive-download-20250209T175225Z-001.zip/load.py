import pandas as pd

# Load the dataset (replace 'path_to_your_dataset.csv' with the actual file path)
data = pd.read_csv('imdb_processed.csv')

# Check the first few rows to confirm the dataset loaded correctly
print(data.head())
# Display column names
print(data.columns)

# Check for missing or problematic data in the `country` column
if 'country' in data.columns:
    print(data['country'].head())
else:
    raise KeyError("The column 'country' is not present in the dataset.")
# Ensure the column values are strings before string operations
data['country'] = data['country'].astype(str).str.strip("[]").str.replace("'", "").str.split(", ")

# Expand rows for titles associated with multiple countries
data = data.explode('country')

# Verify the processed `country` column
print(data['country'].head())
# Drop rows with missing values in `country` or `rating`
data = data.dropna(subset=['country', 'rating'])

# Display the size of the cleaned dataset
print(f"Dataset shape after cleaning: {data.shape}")
from sklearn.preprocessing import OneHotEncoder

# One-hot encode the `country` column
encoder = OneHotEncoder(drop='first', sparse=False)
encoded_countries = encoder.fit_transform(data[['country']])

# Create a DataFrame for encoded columns
encoded_country_df = pd.DataFrame(encoded_countries, columns=encoder.get_feature_names_out(['country']))

# Combine with the original dataset
X = pd.concat([encoded_country_df], axis=1)
y = data['rating']
from sklearn.model_selection import train_test_split

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Display the shape of the training and testing sets
print(f"Training set size: {X_train.shape}, Testing set size: {X_test.shape}")
from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(drop='first', sparse_output=False)
encoded_countries = encoder.fit_transform(data[['country']])
import sklearn
print(sklearn.__version__)