import pandas as pd
from statsmodels.api import OLS, add_constant
import os

# Step 1: Load the dataset
file_path = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping/imdb_processed.csv'
data = pd.read_csv(file_path)

# Step 2: Preprocess the "genre" column
# Remove brackets and split genres into a list
data['genre'] = data['genre'].str.strip("[]").str.replace("'", "").str.split(", ")

# Check for missing genres and fill them with empty lists
data['genre'] = data['genre'].apply(lambda x: x if isinstance(x, list) else [])

# Create dummy variables for genres
genre_dummies = data.explode('genre')['genre'].str.get_dummies()

# Step 3: Combine dummy variables with the main dataset
data_with_genres = pd.concat([data.reset_index(drop=True), genre_dummies.reset_index(drop=True)], axis=1)

# Step 4: Prepare data for regression
# Remove rows with missing values in key columns
data_with_genres = data_with_genres.dropna(subset=['rating', 'runtime', 'vote'])

# Define independent variables (vote, runtime, and genres)
X = data_with_genres[['vote', 'runtime'] + list(genre_dummies.columns)]
y = data_with_genres['rating']

# Add a constant for the regression model
X = add_constant(X)

# Step 5: Fit the regression model
model_genres = OLS(y, X).fit()

# Step 6: Save the regression results to a text file
output_dir = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping'
output_file_genres = os.path.join(output_dir, 'genre_analysis.txt')

# Ensure the directory exists
os.makedirs(output_dir, exist_ok=True)

# Save the regression summary to a text file
with open(output_file_genres, 'w') as f:
    f.write("Regression Analysis: Effect of Genres on Rating\n")
    f.write(str(model_genres.summary()))

print(f"Analysis saved to {output_file_genres}")
