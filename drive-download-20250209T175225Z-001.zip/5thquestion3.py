import pandas as pd

# Load the uploaded CSV file
file_path = '/mnt/data/imdb_processed.csv'
data = pd.read_csv(file_path)

# Display the first few rows of the dataset to understand its structure
data.head()
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
import numpy as np

# Step 1: Clean the 'country' column (extract the first country from the list-like strings)
data['country_cleaned'] = data['country'].str.extract(r"\['(.*?)'\]")

# Step 2: Drop rows with missing 'country_cleaned' or 'rating' values
cleaned_data = data.dropna(subset=['country_cleaned', 'rating'])

# Step 3: One-Hot Encode the 'country_cleaned' column
encoder = OneHotEncoder(sparse=False, drop='first')
country_encoded = encoder.fit_transform(cleaned_data[['country_cleaned']])

# Step 4: Prepare the target and features
X = country_encoded  # Encoded countries
y = cleaned_data['rating']  # Ratings

# Step 5: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Fit the Regression Model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 7: Analyze the Coefficients
coefficients = model.coef_
countries = encoder.categories_[0][1:]  # Exclude the first category (dropped during encoding)
coefficients_df = pd.DataFrame({'Country': countries, 'Coefficient': coefficients})

# Sort by absolute value of coefficients to identify significant countries
coefficients_df['Absolute Coefficient'] = np.abs(coefficients_df['Coefficient'])
coefficients_df = coefficients_df.sort_values(by='Absolute Coefficient', ascending=False)

# Display the coefficients
import ace_tools as tools; tools.display_dataframe_to_user(name="Impact of Country on Ratings", dataframe=coefficients_df)

coefficients_df.head()
