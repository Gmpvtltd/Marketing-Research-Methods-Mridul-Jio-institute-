import pandas as pd

# Load the dataset
data = pd.read_csv('imdb_processed.csv')

# Select relevant columns
data = data[['vote', 'runtime', 'genre', 'rating']]

# Remove rows with missing values
data.dropna(inplace=True)
