import praw

reddit = praw.Reddit(
    client_id='YOUR_CLIENT_ID',
    client_secret='YOUR_CLIENT_SECRET',
    user_agent='YOUR_USER_AGENT'
)

# Test access to a subreddit
subreddit = reddit.subreddit("python")
print(f"Subreddit title: {subreddit.title}")
