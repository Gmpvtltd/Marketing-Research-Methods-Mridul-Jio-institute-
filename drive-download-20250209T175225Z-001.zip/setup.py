import sklearn
import statsmodels.api as sm

print("scikit-learn version:", sklearn.__version__)
print("statsmodels version:", sm.__version__)