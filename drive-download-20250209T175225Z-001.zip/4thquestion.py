import pandas as pd
import os
file_path = os.path.abspath("imdb_processed.csv")
data = pd.read_csv(file_path)
data = pd.read_csv(file_path, encoding='utf-8')

# Load the provided dataset to inspect its contents
file_path = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping/imdb_processed.csv'
data = pd.read_csv(file_path)


# Display the first few rows to understand the structure of the dataset
data.head()
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Select the relevant columns and drop rows with missing values
filtered_data = data[['vote', 'runtime', 'rating', 'year']].dropna()

# Define features (X) and target (y)
X = filtered_data[['runtime', 'rating', 'year']]
y = filtered_data['vote']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

mse, r2
import matplotlib.pyplot as plt

# Residual Plot
residuals = y_test - y_pred

import seaborn as sns

# Distribution of Residuals
# Coefficients of the Features
coefficients = pd.DataFrame({
    "Feature": X.columns,
    "Coefficient": model.coef_
})

plt.figure(figsize=(8, 6))
coefficients.plot(kind='bar', x='Feature', y='Coefficient', legend=False, color='teal')
plt.title("Feature Importance (Coefficients)")
plt.xlabel("Features")
plt.ylabel("Coefficient Value")
plt.grid()
plt.show()

