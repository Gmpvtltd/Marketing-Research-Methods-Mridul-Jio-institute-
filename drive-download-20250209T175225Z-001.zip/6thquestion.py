import pandas as pd
from statsmodels.api import OLS, add_constant

# Load the dataset
file_path = '/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping/imdb_processed.csv'
data = pd.read_csv(file_path)

# Step 1: Preprocess the "director" column to make it usable
data['director'] = data['director'].str.strip("[]").str.replace("'", "").str.split(", ")

# Step 2: Identify directors with more than one entry
director_counts = data.explode('director')['director'].value_counts()
frequent_directors = director_counts[director_counts > 1].index

# Step 3: Create a binary variable for frequent directors
data['frequent_director'] = data['director'].apply(
    lambda x: any(d in frequent_directors for d in x) if isinstance(x, list) else False
)

# Step 4: Perform regression analysis for frequent directors
# Prepare data
data = data.dropna(subset=['rating'])  # Drop rows with missing ratings
data['frequent_director'] = data['frequent_director'].astype(int)  # Convert to 0/1
X = add_constant(data[['frequent_director']])  # Add constant for OLS
y = data['rating']

# Fit the regression model
model = OLS(y, X).fit()

# Output the summary for frequent directors
print("Regression Analysis for Frequent Directors:")
print(model.summary())

# Step 5: Detailed analysis of individual directors' influence
# One-hot encode individual directors
director_dummies = data.explode('director')['director'].str.get_dummies()
data_with_dummies = pd.concat([data.reset_index(drop=True), director_dummies], axis=1)

# Prepare data for regression with individual directors
X_detailed = add_constant(data_with_dummies[director_dummies.columns])  # Add dummies for directors
y_detailed = data_with_dummies['rating']

# Fit the regression model
model_detailed = OLS(y_detailed, X_detailed).fit()

# Output the summary for individual directors
print("\nRegression Analysis for Individual Directors:")
print(model_detailed.summary())
