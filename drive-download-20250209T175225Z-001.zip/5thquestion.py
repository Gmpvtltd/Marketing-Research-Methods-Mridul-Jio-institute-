import pandas as pd

# Load the dataset
file_path = '/mnt/data/imdb_processed.csv'
data = pd.read_csv('/Users/ashutosh/Desktop/Jio/Marketing Research-1/Scraping/imdb_processed.csv')

# Display the first few rows to understand its structure
data.head()
